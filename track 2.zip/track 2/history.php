<?php
session_start();
date_default_timezone_set('Asia/Manila');

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure UTF-8 encoding
$conn->set_charset("utf8mb4");

// Check if POST request to add marker to history
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lat = $_POST['lat'];
    $lng = $_POST['lng'];
    $name = $_POST['name'];
    $timestamp = $_POST['timestamp'];

    // Geocoding to get the exact location address (using OpenCage API)
    $apiKey = 'efb3bdb1602f47daa33b17492c45defe'; // Replace with your geocoding API key
    $url = "https://api.opencagedata.com/geocode/v1/json?q=$lat+$lng&key=$apiKey";
    $response = file_get_contents($url);
    $data = json_decode($response, true);
    $address = isset($data['results'][0]['formatted']) ? $data['results'][0]['formatted'] : 'Address not found';

    // Format timestamp to Philippine standard time (PST) and international standard date
    $timestamp = date('Y-m-d H:i:s', strtotime($timestamp));

    // SQL to insert marker data into history table
    $sql = "INSERT INTO history (lat, lng, name, address, timestamp) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ddsss", $lat, $lng, $name, $address, $timestamp);
    $stmt->execute();
    $stmt->close();

    // Store in session history (optional)
    if (!isset($_SESSION['history'])) {
        $_SESSION['history'] = [];
    }

    // Fetch the last inserted ID to use in session data
    $last_id = $conn->insert_id;

    $_SESSION['history'][] = [
        'id' => $last_id,
        'lat' => $lat,
        'lng' => $lng,
        'name' => $name,
        'address' => $address,
        'timestamp' => $timestamp
    ];

    echo 'History saved.';
    // Redirect to avoid re-posting on page refresh
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Check if GET request to clear history
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['clear']) && $_GET['clear'] == true) {
    $sql_clear = "TRUNCATE TABLE history";
    if ($conn->query($sql_clear) === TRUE) {
        echo 'History cleared.';
        $_SESSION['history'] = [];
    } else {
        echo 'Error clearing history: ' . $conn->error;
    }
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Check if GET request to delete a specific history item
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $deleteId = $_GET['delete'];
    $sql_delete = "DELETE FROM history WHERE id = ?";
    $stmt_delete = $conn->prepare($sql_delete);
    $stmt_delete->bind_param("i", $deleteId);
    if ($stmt_delete->execute()) {
        foreach ($_SESSION['history'] as $index => $marker) {
            if ($marker['id'] == $deleteId) {
                unset($_SESSION['history'][$index]);
                $_SESSION['history'] = array_values($_SESSION['history']);
                break;
            }
        }
        echo 'History item deleted.';
    } else {
        echo 'Error deleting history item: ' . $conn->error;
    }
    $stmt_delete->close();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Marker History</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
    <link href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/output.css">
    <link rel="stylesheet" href="/css/styles.css">
    <link rel="stylesheet" href="/css/style2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0px;
            position: relative;
            background-color: #E7FBE6;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 50px;
            position: relative;
            z-index: 1;
            background-color: white; /* Ensures the table has a solid background */
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 40px;
            text-align: left;
            font-size: 20px;
        }

        th {
            background-color: #f2f2f2;
        }

        .clear-btn {
            display: inline-block;
            padding: 20px 20px;
            background-color: #082D0F;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 20px;
            margin-bottom: 10px;
        }

        .clear-btn:hover {
            background-color: #17B890;
        }

        h1 {
            text-align: center;
        }

        #sidebar {
            width: 20%;
            height: 100vh;
            background-color: white;
        }

        #logo {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100%;
            height: 100%;
            object-fit: contain;
            opacity: 0.4;
            z-index: 0;
        }

        @media (max-width: 700px) {
            span {
                display: none;
            }

            #sidebar {
                width: 10%;
                height: 100vh;
                background-color: white;
            }

            #logo {
                max-width: 60%;
                max-height: 60%;
                opacity: 0.3;
            }
        }
    </style>
</head>

<body>
    <div class="grid grid-cols-5 h-screen">
        <div id="sidebar">
            <?php include('./sidebar-1.php'); ?>
        </div>
        <div class="col-span-4 size-full relative">
            <img id="logo" src="user/images/logo.png" alt="Logo">
            <div class="flex flex-col m-10">
                <!-- Display history table -->
                <?php if (!empty($_SESSION['history'])): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Latitude</th>
                                <th>Longitude</th>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Date and Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($_SESSION['history'] as $index => $marker): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($marker['lat']); ?></td>
                                    <td><?php echo htmlspecialchars($marker['lng']); ?></td>
                                    <td><?php echo htmlspecialchars($marker['name']); ?></td>
                                    <td><?php echo htmlspecialchars($marker['address']); ?></td>
                                    <td><?php echo htmlspecialchars(date('Y-m-d H:i:s', strtotime($marker['timestamp']))); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No markers in history.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
