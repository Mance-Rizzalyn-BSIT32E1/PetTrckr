<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;400;600&family=Montserrat:wght@200&display=swap" rel="stylesheet">
    <title>Welcome!</title>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            font-family: 'Oswald', sans-serif;
            background: url('images/bg.gif') no-repeat center center fixed;
            background-size: cover;
        }

        .container {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: left 10px;
            width: 100%;
            height: 100%;
            text-align: left 10px;
        }

        .header {
            display: flex;
            align-items: left;
            font-size: 2vw;
            color: white;
            position: absolute;
            top: 40px;
            left: 20px;
            margin: 0;
            font-weight: 600;
            text-shadow: 3px 3px 6px rgba(0,0,0,0.5);
        }

        .header img {
            height: 85px;
            width: 100px;
            margin-left: 50px;
            margin-top: 18px;
            padding: 5px;
            border: 2px solid #17B890;
            border-radius: 80%;
        }

        .nav-buttons {
            position: absolute;
            top: 40px;
            right: 20px;
            
        }

        .nav-buttons a {
            display: inline-block;
            color: #00303F;
            background-color: rgba(255, 255, 255, 0.2); /* Light transparent background */
            border: 1px;
            padding: 10px 25px;
            margin-right: 50px;
            margin-top: 18px;
            text-decoration: none;
            font-size: 25px;
            border-bottom: 3px solid #00303F; /* Line border at the bottom */
            border-radius: 1px;
            text-align: center;
        }

        .nav-buttons a:hover {
            background-color: #F5F7F8;
            color: #3e475c;
            transform: scale(1.05);
        }

        .message {
            font-family: 'Montserrat', sans-serif;
            font-weight: 200;
            color: white;
            position: absolute;
            top: 200px;
            font-size: 4vw; /* Adjust font size as needed */
            left: 300px;
            margin: 0;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
        }
        .message h1 {
         font-size: 35px;
         font-weight: 700;
         left: 20px;
         color: #008080;
        }
         .message p {
         font-size: 30px;
         font-weight: 200;
         color: #00303F;
         }
        @media (max-width: 768px) {
            .header {
                font-size: 4vw;
            }

            .header img {
                height: 20px;
            }

            .nav-buttons a {
                font-size: 20px;
                padding: 8px 15px;
                margin-right: 20px;
            }

            .message {
                font-size: 6vw; /* Adjust font size for smaller screens */
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="header">
            <img src="user/images/logo.png" alt="Logo">
        </h1>
        <div class="message">
        <h1>Welcome!</h1>
        <p>Let’s ensure your pet’s happiness together.</p>
        <p>Create a better world for our fur babies.</p>
        </div> <!-- Centered message -->
        <div class="nav-buttons">
            <a href="./user/login.php">Login</a>
            <a href="./user/register.php">Sign Up</a>
        </div>
    </div>
    <script src="./javascript/sessionmessage.js"></script>
</body>
</html>
