
<?php
session_start(); // Start the session
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
    <link href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/output.css">
    <link rel="stylesheet" href="/css/styles.css">
    <link rel="stylesheet" href="/css/style2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <style>
         #sidebar {
            width: 100vw;
            /* Adjust width as needed */
            height: 100vh;
            /* Full height */
            background-color: white;
            /* Sidebar background color */
        }
    </style>
</head>
<body>
    <div class="flex h-screen bg-red-500">
        <div id="sidebar" class="bg-yellow-500">
            <?php include('./sidebar.php'); ?>
        </div>
    </div>
</body>
</html>